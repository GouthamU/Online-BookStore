<?php
    session_start();
    if (!isset($_SESSION['id']) || (trim ($_SESSION['id']) == '')) {
        header('location:Login.html');
        exit();
    }
	else 
	{
		$id= $_SESSION['id'];
		$BookID=$_GET['BookID'];
		$qty=$_POST['qty'];
		$flag=False; 
		$cq=0;
		$CartID="";
		
		
		include('config/dbconn.php');
		$cartQuery = "select * from cart where CustomerID='$id'";
		$cartResult = mysqli_query($dbconn,$cartQuery);
		if($cartResult)
		{			
			while($cart = mysqli_fetch_array($cartResult)) 
			{
				$BID=$cart['BookID'];
				if($BID == $BookID)	
				{
					$flag=True;
					$cq=$cart['OrderQuandity'];
					$CartID=$cart['CartID'];
				}
				
			}
		}
		
		if($flag)
		{
			$cq=$cq+$qty;
			$UpdateQuery="UPDATE cart SET OrderQuandity = '$cq' WHERE (CartID = '$CartID')";
			$UpdateResult = mysqli_query($dbconn,$UpdateQuery);
		}
		else
		{
			$Insertquery = "INSERT INTO cart VALUES (NULL,'$id','$BookID','$qty')";
			$InsertResult = mysqli_query($dbconn,$Insertquery);
		}
		header('Location: BookStore_BookShop.php');
	}
?>

