<?php
	session_start();
	include('config/dbconn.php');
	$_SESSION['id']="";
	header('Location: BookStore_index.php');
?>