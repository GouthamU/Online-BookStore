<?php
    session_start();
    if (!isset($_SESSION['id']) || (trim ($_SESSION['id']) == '')) {
        header('location:Login.html');
        exit();
    }
	else {
		$id= $_SESSION['id'];
		include('config/dbconn.php');
		$cust_query = "SELECT * FROM customer where CustomerID='$id'";
		$cust_result = mysqli_query($dbconn,$cust_query);
		if (mysqli_num_rows($cust_result)==1)
		{
			$customer=mysqli_fetch_array($cust_result);
		}
	}
?>

<!doctype html>
<html class="no-js" lang="zxx">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Shop-Single | Bookshop Responsive Bootstrap4 Template</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Favicons -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/icon.png">

	<!-- Google font (font-family: 'Roboto', sans-serif; Poppins ; Satisfy) -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,600,600i,700,700i,800" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/plugins.css">
	<link rel="stylesheet" href="style.css">

	<!-- Cusom css -->
   <link rel="stylesheet" href="css/custom.css">

	<!-- Modernizer js -->
	<script src="js/vendor/modernizr-3.5.0.min.js"></script>
</head>
<body>
	<!-- Main wrapper -->
	<div class="wrapper" id="wrapper">
		
		<!-- Header -->
		<header id="wn__header" class="header__area header__absolute sticky__header">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-6 col-sm-6 col-6 col-lg-2">
						<div class="logo">
							<a href="BookStore_index.php">
								<img src="images/logo/logo.png" alt="logo images">
							</a>
						</div>
					</div>
					<div class="col-lg-8 d-none d-lg-block">
						<nav class="mainmenu__nav">
							<ul class="meninmenu d-flex justify-content-start">
								<li class="drop with--one--item"><a href="BookStore_index.php">Home</a></li>
								<li class="drop"><a href="BookStore_BookShop.php">Books</a></li>
								<li><a href="BookStore_contact.php">Contact</a></li>
							</ul>
						</nav>
					</div>
					<div class="col-md-6 col-sm-6 col-6 col-lg-2">
						<ul class="header__sidebar__right d-flex justify-content-end align-items-center">
							<li class="shop_search"><a class="search__active" href="#"></a></li>
							<li class="setting__bar__icon"><a class="setting__active" href="#"></a>
								<div class="searchbar__content setting__block">
									<div class="content-inner">
										<div class="switcher-currency">
											<strong class="label switcher-label">
												<span><center><?php echo $customer['FirstName'] ?></center></span>
											</strong>
											<div class="switcher-options">
												<div class="switcher-currency-trigger">
													<div class="setting__menu">
														<span><a href="http://localhost/BookStore/BookStore_MyOrders.php">My Order</a></span>
														<span><a href="http://localhost/BookStore/BookStore_Cart.php">My Cart</a></span>
														<span><a href="http://localhost/BookStore/LogOut.php">Log Out</a></span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</header>
		<!-- End Header -->
		
		<?php
    		include('config/dbconn.php');
    		$BookID=$_GET['BookID'];
    		$query = "SELECT * FROM book join publication on book.PublicationID = publication.PublicationID join category on book.CategoryID=category.CategoryID WHERE BookID='$BookID'";
    		$result = mysqli_query($dbconn,$query);
			$book = mysqli_fetch_array($result);
			$CatID = $book['CategoryID'];
		?>  
        <!-- Start main Content -->
        <div class="maincontent bg--white pt--80 pb--55">
        	<div class="container">
        		<div class="row">
        			<div class="col-lg-9 col-12">
        				<div class="wn__single__product">
        					<div class="row">
        						<div class="col-lg-6 col-12">
        							<div class="wn__fotorama__wrapper">
	        							<div class="fotorama wn__fotorama__action" data-nav="thumbs">
		        							  <a href="1.jpg"><img src="<?php echo $book['ServerImageLocation'] ?>" alt=""></a>
		        							  <a href="2.jpg"><img src="<?php echo $book['ServerImageLocation'] ?>" alt=""></a>
	        							</div>
        							</div>
        						</div>
        						<div class="col-lg-6 col-12">
        							<div class="product__info__main">
        								<h1><?php echo $book['BookName'] ?></h1>
        								<div class="price-box">
        									<span>$ <?php echo $book['Price'] ?></span>
        								</div>
										<div class="product__overview">
        									<p>Description of the above book </p>
        								</div>
        								<div class="box-tocart d-flex">
        									<form action="AddToCart.php?BookID=<?php echo $BookID; ?>" method="post">
												<span>Qty</span>
        										<input id="qty" class="input-text qty" name="qty" min="1" value="1" title="qty" type="number">
        										<div class="addtocart__actions"> 
        											<button class="tocart" type="submit" id="submit" name="submit" title="Add to Cart">Add to Cart</button>
        										</div>
											</form>
        								</div>
										<div class="product_meta">
											<span class="posted_in">Publication: 
												<?php echo $book['PublicationName'] ?>
											</span>
										</div>
        							</div>
        						</div>
        					</div>
        				</div>
        				<!-- Start Related Books Part -->
						<div class="wn__related__product pt--80 pb--50">
							<div class="section__title text-center">
								<h2 class="title__be--2">Related Products</h2>
							</div>
							<div class="row mt--60">
								<div class="productcategory__slide--2 arrows_style owl-carousel owl-theme">
									<?php
										include('config/dbconn.php');
										$relatedquery = "SELECT * FROM book where CategoryID='$CatID' and BookID!='$BookID' ORDER BY BookName ASC";
										$relatedresult = mysqli_query($dbconn,$relatedquery);
										if($relatedresult)
										{
                                            while($Relatedbook = mysqli_fetch_array($relatedresult)) 
											{ 
												echo "<div class='product product__style--3 col-lg-4 col-md-4 col-sm-6 col-12'>";
			        							echo "<div class='product__thumb'>";
												echo "<a class='first__img' href='BookStore_SingleBook.php?BookID=".$Relatedbook['BookID']."'><img src='".$Relatedbook['ServerImageLocation']."' alt='product image'></a>";
												echo "<a class='second__img animation1' href='BookStore_SingleBook.php?BookID=".$Relatedbook['BookID']."'><img src='".$Relatedbook['ServerImageLocation']."' alt='product image'></a>";
												echo "</div>";
												echo "<div class='product__content content--center'>";
												echo "<h4><a href='single-product.html'>".$Relatedbook['BookName']."</a></h4>";
												echo "<ul class='prize d-flex'>";
												echo "<li>$ ".$Relatedbook['Price']."</li>";
												echo "</ul>";
												echo "<div class='action'>";
												echo "<div class='actions_inner'>";
												echo "<ul class='add_to_links'>";
												echo "<li><a class='wishlist' href='wishlist.html'><i class='bi bi-shopping-cart-full'></i></a></li>";
												echo "</ul>";
												echo "</div>";
												echo "</div>";
												echo "</div>";
		        								echo "</div>";
											}
										}
                                    ?>
								</div>
							</div>
						</div>
						<!-- End Related Books Part -->
        			</div>
        		</div>
        	</div>
        </div>
        <!-- End main Content -->
		
		<!-- Footer Area -->
		<footer id="wn__footer" class="footer__area bg__cat--8 brown--color">
			<div class="footer-static-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="footer__widget footer__menu">
								<div class="ft__logo">
									<a href="index.html">
										<img src="images/logo/3.png" alt="logo">
									</a>
								</div>
								<div class="footer__content">
									<ul class="social__net social__net--2 d-flex justify-content-center">
										<li><a href="#"><i class="bi bi-facebook"></i></a></li>
										<li><a href="#"><i class="bi bi-google"></i></a></li>
										<li><a href="#"><i class="bi bi-twitter"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- End Footer Area -->
		
	</div>
	<!-- //Main wrapper -->
	
	<!-- JS Files -->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/plugins.js"></script>
	<script src="js/active.js"></script>
	
</body>
</html>