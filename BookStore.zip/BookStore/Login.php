<?php
    session_start();
    if (!isset($_SESSION['id']) || (trim ($_SESSION['id']) == '')) {
        
    }
	else {
		header('location:BookStore_BookShop.php');
        exit();
	}
?>

<!doctype html>
<html class="no-js" lang="zxx">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Login</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Favicons -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/icon.png">

	<!-- Google font (font-family: 'Roboto', sans-serif; Poppins ; Satisfy) -->
	<link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i,900" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,600,600i,700,700i,800" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Satisfy" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/plugins.css">
	<link rel="stylesheet" href="style.css">

	<!-- Cusom css -->
   <link rel="stylesheet" href="css/custom.css">

	<!-- Modernizer js -->
	<script src="js/vendor/modernizr-3.5.0.min.js"></script>
</head>
<body>
	<!-- Main wrapper -->
	<div class="wrapper" id="wrapper">
		
	<!-- Header -->
	<header id="wn__header" class="oth-page header__area header__absolute sticky__header">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-4 col-sm-4 col-7 col-lg-2">
					<div class="logo">
						<a href="BookStore_index.php"> <img src="images/logo/logo.png" alt="logo images"> </a>
					</div>
				</div>
				<div class="col-lg-8 d-none d-lg-block">
					<nav class="mainmenu__nav">
						<ul class="meninmenu d-flex justify-content-start">
							<li class="drop"><a href="BookStore_index.php">Home</a></li>
							<li class="drop"><a href="BookStore_BookShop.php">Shop</a></li>
							<li><a href="BookStore_contact.html">Contact</a></li>
						</ul>
					</nav>
				</div>
				<div class="col-md-8 col-sm-8 col-5 col-lg-2">
					<ul class="header__sidebar__right d-flex justify-content-end align-items-center">
						<li class="setting__bar__icon"><a class="setting__active" href="#"></a>
							<div class="searchbar__content setting__block">
								<div class="content-inner">
									<div class="switcher-currency">
										<strong class="label switcher-label">
											<span>My Account</span>
										</strong>
										<div class="switcher-options">
											<div class="switcher-currency-trigger">
												<div class="setting__menu">
													<span><a href="Login.php">Sign In</a></span>
													<span><a href="SignUp.php">Create An Account</a></span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
			
			<!-- Start Mobile Menu -->
			<div class="row d-none">
				<div class="col-lg-12 d-none">
					<nav class="mobilemenu__nav">
						<ul class="meninmenu">
							<li><a href="BookStore_index.php">Home</a></li>
							<li class="drop"><a href="BookStore_BookShop.php">Shop</a></li>
							<li><a href="BookStore_contact.html">Contact</a></li>
						</ul>
					</nav>
				</div>
			</div>
			<!-- End Mobile Menu -->
		
		</div>		
	</header>
        <!-- End Header -->
        
		<!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area bg-image--6">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="bradcaump__inner text-center">
                        	<h2 class="bradcaump-title">My Account</h2>
                            <nav class="bradcaump-content">
                              <a class="breadcrumb_item" href="BookStore_index.php">Home</a>
                              <span class="brd-separetor">/</span>
                              <span class="breadcrumb_item active">My Account</span>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
	
		<!-- Start Login Area -->
		<section class="my_account_area pt--80 pb--55 bg--white">
			<div class="container" align="center">
				<div class="col-lg-6 col-12">
					<?php 
						$msg=isset($_SESSION['msg']) ? $_SESSION['msg'] : ''; 
						echo "<h5><font color='red'>".$msg."</font></h5>";
						echo"<br>";
						echo"<br>";
					?>
					<div class="my__account__wrapper">
						<h3 class="account__title"><font color='#CE7852'>Customer Login Portal</font></h3>
						<form method="POST" action="LoginValidation.php">
							<div class="account__form">
								<div class="input__box">
									<label>Email<span>*</span></label>
									<input type="email" name="email" class="form-control" placeholder="Email">
								</div>
								<div class="input__box">
									<label>Password<span>*</span></label>
									<input type="password" name="password" placeholder="Password" class="form-control">
								</div>
								<div class="form__btn">
									<button type="submit" name="submit">Login</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</section>

		<!-- Footer Area -->
		<footer id="wn__footer" class="footer__area bg__cat--8 brown--color">
			<div class="footer-static-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="footer__widget footer__menu">
								<div class="ft__logo">
									<a href="BookStore_index.php">
										<img src="images/logo/3.png" alt="logo">
									</a>
								</div>
								<div class="footer__content">
									<ul class="social__net social__net--2 d-flex justify-content-center">
										<li><a href="#"><i class="bi bi-facebook"></i></a></li>
										<li><a href="#"><i class="bi bi-google"></i></a></li>
										<li><a href="#"><i class="bi bi-twitter"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- //Footer Area -->
		
	</div>
	<!-- //Main wrapper -->

	<!-- JS Files -->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/plugins.js"></script>
	<script src="js/active.js"></script>
	
</body>
</html>