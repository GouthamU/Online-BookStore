<?php
    session_start();
    if (!isset($_SESSION['id']) || (trim ($_SESSION['id']) == '')) {
        header('location:Login.html');
        exit();
    }
	else 
	{
		include('config/dbconn.php');
		
		$id= $_SESSION['id'];
		$BookID=$_POST['BookID'];
		$Author=$_POST['Author'];
		$Price=$_POST['Price'];
		$qty=$_POST['Quandity'];
		
		$AdminUpdateQuery= "UPDATE book SET Author='$Author', Price='$Price', Quandity='$qty' WHERE (BookID='$BookID')";
		$AdminUpdateResult = mysqli_query($dbconn,$AdminUpdateQuery);
		echo $AdminUpdateQuery;
		header('Location: Admin.php');
	}
?>