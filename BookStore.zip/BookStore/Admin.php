﻿<?php
    session_start();
    if (!isset($_SESSION['id']) || (trim ($_SESSION['id']) == '')) {
        header('location:AdminLogin.php');
        exit();
    }
	else {
		$AdminID= $_SESSION['id'];
		include('config/dbconn.php');
		$cust_query = "SELECT * FROM administrator join publication on AdminPublication=PublicationID where AdminID='$AdminID'";
		$cust_result = mysqli_query($dbconn,$cust_query);
		if (mysqli_num_rows($cust_result)==1)
		{
			$customer=mysqli_fetch_array($cust_result);
		}
	}
?>

<!doctype html>
<html class="no-js" lang="zxx">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Shopping Cart | Bookshop Responsive Bootstrap4 Template</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Favicons -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/icon.png">

	<!-- Google font (font-family: 'Roboto', sans-serif; Poppins ; Satisfy) -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,600,600i,700,700i,800" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/plugins.css">
	<link rel="stylesheet" href="style.css">

	<!-- Cusom css -->
   <link rel="stylesheet" href="css/custom.css">

	<!-- Modernizer js -->
	<script src="js/vendor/modernizr-3.5.0.min.js"></script>
</head>
<body>
	<!-- Main wrapper -->
	<div class="wrapper" id="wrapper">
		
		<!-- Header -->
		<header id="wn__header" class="header__area header__absolute sticky__header">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-6 col-sm-6 col-6 col-lg-2">
						<div class="logo">
							<a href="BookStore_index.html">
								<img src="images/logo/logo.png" alt="logo images">
							</a>
						</div>
					</div>
					<div class="col-lg-8 d-none d-lg-block">
						<nav class="mainmenu__nav">
							<ul class="meninmenu d-flex justify-content-start">
								<li class="drop with--one--item"><a href="BookStore_index.html"></a></li>
								<li class="drop"><a href="BookStore_BookShop.html"></a>
								</li>
								<li><a href="BookStore_contact.html"></a></li>
							</ul>
						</nav>
					</div>
					<div class="col-md-6 col-sm-6 col-6 col-lg-2">
						<ul class="header__sidebar__right d-flex justify-content-end align-items-center">
							<li class="setting__bar__icon"><a class="setting__active" href="#"></a>
								<div class="searchbar__content setting__block">
									<div class="content-inner">
										<div class="switcher-currency">
											<strong class="label switcher-label">
												<span><center><?php echo $customer['AdminName'] ?></center></span>
											</strong>
											<div class="switcher-options">
												<div class="switcher-currency-trigger">
													<div class="setting__menu">
														<span><a href="http://localhost/BookStore/LogOut.php">Sign Out</a></span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</header>
		<!-- End Header -->
		
        <!-- cart-main-area start -->
		<br><br><br><br><br><br>
		<h2><center><?php echo $customer['PublicationName'] ?>'s Books List</center></h2>
		<br>
		<div class="container">
			<div class="col-md-12 col-sm-12 ol-lg-12">
				<div class="table-content wnro__table table-responsive">
					<table>
						<thead>
							<tr class="title-top">
								<th class="product-thumbnail">Image</th>
								<th class="product-name">Product</th>
								<th class="product-price">Price</th>
								<th class="product-quantity">Quantity</th>
								<th class="product-subtotal">Update</th>
								<th class="product-remove">Remove</th>
							</tr>
						</thead>
						<tbody>
							<?php
								include('config/dbconn.php');
								$AdminID=$_SESSION['id'];
								$query = "SELECT * FROM book where PublicationID in (select AdminPublication from administrator where AdminID='$AdminID')";
								$result = mysqli_query($dbconn,$query);
								if($result)
								{
									while($book = mysqli_fetch_array($result)) 
									{ 
										echo "<tr>";
										echo "<td class='product-thumbnail'><img src='".$book['ServerImageLocation']."' alt='product img'></td>";
										echo "<td class='product-name'>".$book['BookName']."</td>";
										echo "<td class='product-price'><span class='amount'>$".$book['Price']."</span></td>";
										echo "<td class='product-quantity'><input type='number' value=".$book['Quandity']."></td>";
										echo "<td class='product-remove'><a href='AdminSingleBook.php?BookID=".$book['BookID']."'>Edit</a></td>";
										echo "<td class='product-remove'>X</td>";
										echo "</tr>";
									}
								}
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>						
        <!-- cart-main-area end -->
		
		<!-- Footer Area -->
		<footer id="wn__footer" class="footer__area bg__cat--8 brown--color">
			<div class="footer-static-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="footer__widget footer__menu">
								<div class="ft__logo">
									<a href="index.html">
										<img src="images/logo/logo.png" alt="logo">
									</a>
								    <div class="footer__content">
									   <ul class="social__net social__net--2 d-flex justify-content-center">
										  <li><a href="#"><i class="bi bi-facebook"></i></a></li>
										  <li><a href="#"><i class="bi bi-google"></i></a></li>
										  <li><a href="#"><i class="bi bi-twitter"></i></a></li>
									   </ul>
								    </div>
							     </div>
                            </div>
					       </div>
				    </div>
			     </div>
                </div>
        </footer>
		<!-- //Footer Area -->

	</div>
	<!-- //Main wrapper -->

	<!-- JS Files -->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/plugins.js"></script>
	<script src="js/active.js"></script>
	
</body>
</html>