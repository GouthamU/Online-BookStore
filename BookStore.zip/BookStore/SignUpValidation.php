<?php
	session_start();
	include("config/dbconn.php");
	if(isset($_POST['submit']))
	{   
		$email=$_POST['email'];
		$firstname=$_POST['fname'];
		$lastname=$_POST['lname'];
		$dob=$_POST['dob'];
		$gender=$_POST['gender'];
		$phno=$_POST['phno'];
		$addr1=$_POST['addr1'];
		$addr2=$_POST['addr2'];
		$city=$_POST['city'];
		$zipcode=$_POST['zipcode'];
		$password=$_POST['password'];

		if(empty($email) || empty($firstname) || empty($lastname) || empty($dob) || empty($gender) || empty($phno) || empty($addr1) || empty($addr2) || empty($city) || 
		   empty($zipcode) || empty($password)) 
		{ 
			if(empty($email)) { echo "<font color='red'> Email field is empty!</font><br/>";}
			if(empty($firstname)) { echo "<font color='red'>Firstname field is empty!</font><br/>";}
			if(empty($lastname)) { echo "<font color='red'>Lastname field is empty!</font><br/>"; }
			if(empty($dob)) { echo "<font color='red'> Date of Birth field is empty!</font><br/>"; }
			if(empty($gender)) { echo "<font color='red'> Gender field is empty!</font><br/>"; }
			if(empty($phno)) { echo "<font color='red'> Phone Number field is empty!</font><br/>"; }
			if(empty($addr1)) { echo "<font color='red'> Address Line 1 field is empty!</font><br/>";}
			if(empty($addr2)) { echo "<font color='red'> Address Line 2 field is empty!</font><br/>";}
			if(empty($city)) { echo "<font color='red'> field is empty!</font><br/>"; }
			if(empty($zipcode)) { echo "<font color='red'> City field is empty!</font><br/>"; }
			if(empty($password)) { echo "<font color='red'>Password field is empty!</font><br/>"; }    
		} 
		else 
		{
			$query = "INSERT INTO customer VALUES (NULL, '$email', '$firstname', '$lastname', '$dob', '$gender', '$phno', '$addr1', '$addr2', '$city', '$zipcode', '$password')";
			$result = mysqli_query($dbconn,$query);
			echo "Surya Wins";
			header('Location: BookStore_index.php');
		}
	}
?>
		<!-- PHP Code End -->