<?php
    session_start();
    if (!isset($_SESSION['id']) || (trim ($_SESSION['id']) == '')) {
        header('location:Login.php');
        exit();
    }
	else {
		$id= $_SESSION['id'];
		include('config/dbconn.php');
		$cust_query = "SELECT * FROM customer where CustomerID='$id'";
		$cust_result = mysqli_query($dbconn,$cust_query);
		if (mysqli_num_rows($cust_result)==1)
		{
			$customer=mysqli_fetch_array($cust_result);
		}
	}
?>

<!doctype html>
<html class="no-js" lang="zxx">
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Checkout</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Favicons -->
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="apple-touch-icon" href="images/icon.png">

	<!-- Google font (font-family: 'Roboto', sans-serif; Poppins ; Satisfy) -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,600,600i,700,700i,800" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet"> 

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/plugins.css">
	<link rel="stylesheet" href="style.css">

	<!-- Cusom css -->
   <link rel="stylesheet" href="css/custom.css">

	<!-- Modernizer js -->
	<script src="js/vendor/modernizr-3.5.0.min.js"></script>
</head>
<body>
	<!-- Main wrapper -->
	<div class="wrapper" id="wrapper">
		
		<!-- Header -->
		<header id="wn__header" class="header__area header__absolute sticky__header">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-6 col-sm-6 col-6 col-lg-2">
						<div class="logo">
							<a href="BookStore_index.php">
								<img src="images/logo/logo.png" alt="logo images">
							</a>
						</div>
					</div>
					<div class="col-lg-8 d-none d-lg-block">
						<nav class="mainmenu__nav">
							<ul class="meninmenu d-flex justify-content-start">
								<li class="drop with--one--item"><a href="BookStore_index.php">Home</a></li>
								<li class="drop"><a href="BookStore_BookShop.php">Books</a></li>
								<li><a href="BookStore_contact.html">Contact</a></li>
							</ul>
						</nav>
					</div>
					<div class="col-md-6 col-sm-6 col-6 col-lg-2">
						<ul class="header__sidebar__right d-flex justify-content-end align-items-center">
							<li class="shop_search"><a class="search__active" href="#"></a></li>
							<li class="setting__bar__icon"><a class="setting__active" href="#"></a>
								<div class="searchbar__content setting__block">
									<div class="content-inner">
										<div class="switcher-currency">
											<strong class="label switcher-label">
												<span><center><?php echo $customer['FirstName'] ?></center></span>
											</strong>
											<div class="switcher-options">
												<div class="switcher-currency-trigger">
													<div class="setting__menu">
														<span><a href="http://localhost/BookStore/BookStore_MyOrders.php">My Order</a></span>
														<span><a href="http://localhost/BookStore/BookStore_Cart.php">My Cart</a></span>
														<span><a href="http://localhost/BookStore/LogOut.php">Log Out</a></span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</header>
		<!-- End Header -->
		
        <!-- Start Checkout Area -->
		<br>
		<br>
		<br>
       <section class="wn__checkout__area section-padding--lg bg__white">
        	<div class="container">
        		<div class="row">
        			<div class="col-lg-6 col-12">
        				<div class="customer_details">
        					<div class="che__header" role="tab" id="headingFour">
								<a class="collapsed checkout__title" aria-expanded="false" aria-controls="collapseFour">
									<span><b>Billing Details</b></span>
								</a>
							</div>
							<form method="post" action="PlaceOrder.php">
								<div class="customar__field">
									<div class="margin_between">
										<div class="input_box space_between">
											<label>First name <span>*</span></label>
											<input type="text" value="<?php echo $customer['FirstName'] ?>" required>
										</div>
										<div class="input_box space_between">
											<label>Last name <span>*</span></label>
											<input type="text" value="<?php echo $customer['LastName'] ?>" required>
										</div>
									</div>
									
									<div class="input_box">
										<label>Address Line 1 <span>*</span></label>
										<input type="text" value="<?php echo $customer['Addr1'] ?>" required>
									</div>
									<div class="input_box">
										<label>Address Line 2 <span>*</span></label>
										<input type="text" value="<?php echo $customer['Addr2'] ?>" required>
									</div>
									<div class="margin_between">
										<div class="input_box space_between">
											<label>City <span>*</span></label>
											<input type="text" value="<?php echo $customer['City'] ?>" required>
										</div>
										<div class="input_box space_between">
											<label>ZipCode <span>*</span></label>
											<input type="text" value="<?php echo $customer['Zipcode'] ?>" required>
										</div>
									</div>
									<div class="input_box">
										<label>Phone <span>*</span></label>
											<input type="text" value="<?php echo $customer['PhNo'] ?>" required>
									</div>
									<div class="input_box">
										<label>Email address<span>*</span></label>
										<input type="text" value="<?php echo $customer['Email'] ?>" required>
									</div>
									<div class="che__header" role="tab" id="headingFour">
										<a class="collapsed checkout__title" aria-expanded="false" aria-controls="collapseFour">
											<span><b>Card Payment</b></span>
										</a>
									</div>
									<div class="input_box">
										<label>Card Number <span>*</span></label>
										<input type="text" value="00000" required>
									</div>
									<div class="margin_between">
										<div class="input_box space_between">
											<label>Exp. Month<span>*</span></label>
											<select class="select__option" required>
												<option value="01">January</option>
												<option value="02">February </option>
												<option value="03">March</option>
												<option value="04">April</option>
												<option value="05">May</option>
												<option value="06">June</option>
												<option value="07">July</option>
												<option value="08">August</option>
												<option value="09">September</option>
												<option value="10">October</option>
												<option value="11">November</option>
												<option value="12">December</option>
											</select>
										</div>
										<div class="input_box space_between">
											<label>Exp. Year<span>*</span></label>
											<select class="select__option" required>
												<option value="19"> 2019</option>
												<option value="20"> 2020</option>
												<option value="21"> 2021</option>
												<option value="22"> 2022</option>
												<option value="23"> 2023</option>
												<option value="24"> 2024</option>
											</select>
										</div>
									</div>
									<div class="margin_between">
										<div class="input_box space_between">
											<label>CVV <span>*</span></label>
											<input type="text" value="00000" required>
										</div>		
										<div class="input_box space_between">
											<label>Zip Code <span>*</span></label>
											<input type="text" value="00000" required>
										</div>
									</div>
									<div class="input_box space_between" >
										<ul class="cart__btn__list d-flex flex-wrap flex-md-nowrap flex-lg-nowrap justify-content-between">
											<button type="submit" title="Place Order">Place Order</button>
										</ul>	
									</div>
								</div>
							</form>
        				</div>
        			</div>
        			<div class="col-lg-6 col-12 md-mt-40 sm-mt-40">
        				<div class="wn__order__box">
        					<h3 class="onder__title">Your order</h3>
        					<ul class="order__total">
        						<li>Product</li>
        						<li>Total</li>
        					</ul>
        					<ul class="order_product">
								<?php
									include('config/dbconn.php');
									$cartTotal=0;
									$tax=0;
									$GrandTotal=0;
									$query = "SELECT * FROM cart join book on book.BookID=cart.BookID where CustomerID='$id'";
									$result = mysqli_query($dbconn,$query);
									if($result)
									{
										while($cart = mysqli_fetch_array($result)) 
										{ 
											$p=$cart['Price'];
											$q=$cart['OrderQuandity'];
											$subtotal=$p*$q;
											echo "<li>".$cart['BookName']." x ".$q."<span>$".$subtotal."</span></li>";
											$cartTotal=$cartTotal+$subtotal;
										}
										$tax=0.03*$cartTotal;
										$tax=round($tax,2);
										$GrandTotal=$tax+$cartTotal;
										echo "</ul>";
										echo "<ul class='shipping__method'>";
										echo "<li>Cart Subtotal <span>$".$cartTotal."</span></li>";
										echo "<li>Tax <span>$".$tax."</span></li>";
										echo "</ul>";
										echo "<ul class='total__amount'>";
										echo "<li>Order Total <span>$ ".$GrandTotal."</span></li>";
										echo "</ul>";
									}
                                ?>
        				</div>
        			</div>		
        		</div>
        	</div>
        </section>
        <!-- End Checkout Area -->
		
		<!-- Footer Area -->
		<footer id="wn__footer" class="footer__area bg__cat--8 brown--color">
			<div class="footer-static-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="footer__widget footer__menu">
								<div class="ft__logo">
									<a href="BookStore_index.html">
										<img src="images/logo/3.png" alt="logo">
									</a>
								</div>
								<div class="footer__content">
									<ul class="social__net social__net--2 d-flex justify-content-center">
										<li><a href="#"><i class="bi bi-facebook"></i></a></li>
										<li><a href="#"><i class="bi bi-google"></i></a></li>
										<li><a href="#"><i class="bi bi-twitter"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- //Footer Area -->

	</div>
	<!-- //Main wrapper -->

	<!-- JS Files -->
	<script src="js/vendor/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/plugins.js"></script>
	<script src="js/active.js"></script>
	
</body>
</html>