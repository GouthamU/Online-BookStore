﻿<?php
	session_start();
	include('config/dbconn.php');
	if(isset($_POST['submit']))
	{    
		$email=$_POST['email'];
		$pass=$_POST['password'];          
		$query=mysqli_query($dbconn,"SELECT * FROM customer WHERE email='$email' AND pass='$pass'");

		if (mysqli_num_rows($query)<1){
			$_SESSION['msg']="Login Failed, User not found!";
			header('Location: Login.php');
		}
		else{
			$res=mysqli_fetch_array($query);
			$_SESSION['msg']="";
			$_SESSION['id']=$res['CustomerID'];
			header('Location: BookStore_BookShop.php');
		}
	}
?>