create database BookStore;

use BookStore;

create TABLE `Customer` (
	CustomerID int Primary Key AUTO_INCREMENT,
	Email varchar(50) Unique NOT NULL,
	FirstName varchar(50) NOT NULL,
	LastName varchar(50) NOT NULL,
	DateOfBirth date NOT NULL,
	Gender varchar(50) NOT NULL,
	PhNo varchar(50) NOT NULL,
	Addr1 varchar(50) NOT NULL,
	Addr2 varchar(50) NOT NULL,
	City varchar(50) NOT NULL,
	Zipcode varchar(50) NOT NULL,
	Pass varchar(50) NOT NULL
);

ALTER TABLE Customer AUTO_INCREMENT = 10001;

create table Publication (
	PublicationID varchar(500) Primary Key,
	PublicationName varchar(500) NOT NULL,
	PublicationAddress varchar(500) NOT NULL,
	PublicationEmail varchar(500) NOT NULL
);

create table Administrator (
	AdminID varchar(50) Primary Key,
    AdminName varchar(50) NOT NULL,
    AdminPhNo varchar(50) NOT NULL,
    AdminEmail varchar(50) NOT NULL,
    AdminPublication varchar(50) NOT NULL,
    FOREIGN KEY (AdminPublication) REFERENCES Publication(PublicationID) ON UPDATE CASCADE
);

create table Category (
	CategoryID varchar(50) Primary Key,
	CategoryName varchar(50) NOT NULL
);

create table Book (
	BookID varchar(50) Primary Key,
	BookName varchar(500) NOT NULL,
	Author varchar(50) NOT NULL,
	Price varchar(50) NOT NULL,
	PublicationID varchar(50) NOT NULL,
	CategoryID varchar(50) NOT NULL,
	ISBN10 varchar(50) NOT NULL,
	ISBN13 varchar(50) NOT NULL,
	Quandity int NOT NULL,
	ServerImageLocation varchar(100) NOT NULL,
    FOREIGN KEY (PublicationID) REFERENCES Publication(PublicationID) ON UPDATE CASCADE,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID) ON UPDATE CASCADE
);

create table Cart (
	CartID int Primary Key AUTO_INCREMENT,
	CustomerID int NOT NULL,
	BookID varchar(50) NOT NULL,
	OrderQuandity int NOT NULL,
	FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID) ON UPDATE CASCADE,
	FOREIGN KEY (BookID) REFERENCES Book(BookID) ON UPDATE CASCADE
);
ALTER TABLE Cart AUTO_INCREMENT = 101;

create table Orders (
	OrderID int Primary Key AUTO_INCREMENT,
	CustomerID int NOT NULL,
	DateOfOrder DATE NOT NULL,
	FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID) ON UPDATE CASCADE
);
ALTER TABLE Orders AUTO_INCREMENT = 5001;

create table OrderDetails (
	OrderDetailsID int Primary Key AUTO_INCREMENT,
	OrderID int NOT NULL,
	BookID varchar(50) NOT NULL,
	OrderQuandity int NOT NULL,
	OrderPrice float NOT NULL,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID) ON UPDATE CASCADE,
    FOREIGN KEY (BookID) REFERENCES Book(BookID) ON UPDATE CASCADE
);
ALTER TABLE OrderDetails AUTO_INCREMENT = 7001;

create table Payment (
	PaymentID int Primary Key AUTO_INCREMENT,
	OrderID int NOT NULL,
	DateOfPayment DATE NOT NULL,
	TotalAmount float NOT NULL,
	ModeOfPayment varchar(50) NOT NULL,
	SuccessFlag varchar(5) NOT NULL,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID) ON UPDATE CASCADE
);
ALTER TABLE Payment AUTO_INCREMENT = 9001;