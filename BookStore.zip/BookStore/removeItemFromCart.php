<?php
    session_start();
    if (!isset($_SESSION['id']) || (trim ($_SESSION['id']) == '')) {
        header('location:Login.html');
        exit();
    }
	else {
		$id= $_SESSION['id'];
		include('config/dbconn.php');
		$cust_query = "SELECT * FROM customer where CustomerID='$id'";
		$cust_result = mysqli_query($dbconn,$cust_query);
		if (mysqli_num_rows($cust_result)==1)
		{
			$customer=mysqli_fetch_array($cust_result);
		}
	}


	include('config/dbconn.php');
	$BookID=$_GET['BookID'];
	$id= $_SESSION['id'];
	$query = "delete from cart where BookID='$BookID' and CustomerID='$id';";
	$result = mysqli_query($dbconn,$query);
	header('Location: BookStore_Cart.php');
?>