<?php
    session_start();
    if (!isset($_SESSION['id']) || (trim ($_SESSION['id']) == '')) {
        header('location:Login.html');
        exit();
    }
	else {
		$id= $_SESSION['id'];
		include('config/dbconn.php');
		$cust_query = "SELECT * FROM customer where CustomerID='$id'";
		$cust_result = mysqli_query($dbconn,$cust_query);
		if (mysqli_num_rows($cust_result)==1)
		{
			$customer=mysqli_fetch_array($cust_result);
		}
	}


	include('config/dbconn.php');
	$id= $_SESSION['id'];
	$cartQuery = "select * from cart join book on cart.BookID=book.BookID where CustomerID='$id'";
	$cartResult = mysqli_query($dbconn,$cartQuery);

	$orderQuery="insert into orders values (NULL, '$id', '".date("Y-m-d")."')";
	$orderResult = mysqli_query($dbconn,$orderQuery);

	$q1="select max(OrderID) as id from orders";
	$q1Result=mysqli_query($dbconn,$q1);
	$q1Ans=mysqli_fetch_array($q1Result);
	$OrderID=$q1Ans['id'];
	$totalPrice=0;
	if($cartResult)
	{
		while($cart = mysqli_fetch_array($cartResult)) 
		{
			$price=$cart['OrderQuandity']*$cart['Price'];
			$totalPrice=$totalPrice+$price;
			$BID=$cart['BookID'];
			$OQ=$cart['OrderQuandity'];
			$orderdetailsQuery="insert into orderdetails values (NULL, '$OrderID', '$BID', '$OQ', '$price')";
			$orderdetailsResult = mysqli_query($dbconn,$orderdetailsQuery);
		}
	}
	$tax=0.03*$totalPrice;
	$tax=round($tax,2);
	$totalPrice=$totalPrice+$tax;

	$paymentQuery="insert into payment values (NULL, '$OrderID', '".date("Y-m-d")."', '$totalPrice', 'Credit Card', 'Y')";
	$paymentResult = mysqli_query($dbconn,$paymentQuery);
	
	$deleteCartQuery = "delete from cart where CustomerID='$id'";
	$deleteCartQueryResult = mysqli_query($dbconn,$deleteCartQuery);
	
	
	header('Location: BookStore_Cart.php');
?>